CREATE PROCEDURE ManageSubjectAllotments
    @StudentId VARCHAR(20),
    @SubjectId VARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @CurrentSubject VARCHAR(20);

    SELECT TOP 1 @CurrentSubject = SubjectId
    FROM SubjectAllotments
    WHERE StudentId = @StudentId
    AND Is_Valid = 1
    ORDER BY SubjectId; 

    IF @CurrentSubject IS NULL
    BEGIN
        INSERT INTO SubjectAllotments (StudentId, SubjectId, Is_Valid)
        VALUES (@StudentId, @SubjectId, 1);
    END
    ELSE
    BEGIN
        IF @CurrentSubject <> @SubjectId
        BEGIN
            UPDATE SubjectAllotments
            SET Is_Valid = 0
            WHERE StudentId = @StudentId
            AND Is_Valid = 1;

            INSERT INTO SubjectAllotments (StudentId, SubjectId, Is_Valid)
            VALUES (@StudentId, @SubjectId, 1);
        END
    END
END;