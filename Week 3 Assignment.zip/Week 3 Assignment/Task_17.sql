USE master;
CREATE LOGIN YourLoginName WITH PASSWORD = 'YourStrongPassword';

USE AdventureWorks2019
CREATE USER YourUserName FOR LOGIN YourLoginName;

ALTER ROLE db_owner ADD MEMBER YourUserName;