WITH DailySubmissionCounts AS (
    SELECT
        submission_date,
        hacker_id,
        COUNT(*) AS num_submissions,
        RANK() OVER (PARTITION BY submission_date ORDER BY COUNT(*) DESC, hacker_id) AS submission_rank
    FROM
        Submissions
    GROUP BY
        submission_date,
        hacker_id
),
UniqueHackersPerDay AS (
    SELECT
        submission_date,
        COUNT(DISTINCT hacker_id) AS num_unique_hackers
    FROM
        Submissions
    GROUP BY
        submission_date
)
SELECT
    DSC.submission_date,
    UHD.num_unique_hackers,
    DSC.hacker_id,
    H.name
FROM
    DailySubmissionCounts DSC
JOIN
    UniqueHackersPerDay UHD ON DSC.submission_date = UHD.submission_date
JOIN
    Hackers H ON DSC.hacker_id = H.hacker_id
WHERE
    DSC.submission_rank = 1
ORDER BY
    DSC.submission_date;