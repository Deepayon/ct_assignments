SELECT 
    c.company_code,
    f.founder_name,
    COALESCE(COUNT(DISTINCT lm.employee_id), 0) AS total_lead_managers,
    COALESCE(COUNT(DISTINCT sm.employee_id), 0) AS total_senior_managers,
    COALESCE(COUNT(DISTINCT mgr.employee_id), 0) AS total_managers,
    COALESCE(COUNT(DISTINCT emp.employee_id), 0) AS total_employees
FROM Company c
JOIN founders f ON c.company_code = f.company_code
LEFT JOIN LeadManager lm ON c.company_code = lm.company_code
LEFT JOIN SeniorManager sm ON c.company_code = sm.company_code
LEFT JOIN Manager mgr ON c.company_code = mgr.company_code
LEFT JOIN Employee emp ON c.company_code = emp.company_code
GROUP BY c.company_code, f.founder_name
ORDER BY c.company_code ASC;