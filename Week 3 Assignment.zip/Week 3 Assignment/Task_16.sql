DECLARE @Salary INT = 5000;
DECLARE @Bonus INT = 1000;

SELECT 'Before Swap' AS Status, @Salary AS Salary, @Bonus AS Bonus;

SET @Salary = @Salary + @Bonus;
SET @Bonus = @Salary - @Bonus;
SET @Salary = @Salary - @Bonus;

SELECT 'After Swap' AS Status, @Salary AS Salary, @Bonus AS Bonus;
