CREATE TABLE Projects (
    Task_ID INTEGER,
    Start_Date DATE,
    End_Date DATE,
    CONSTRAINT chk_date_diff CHECK (DATEDIFF(day, Start_Date, End_Date) = 1)
);