CREATE TABLE Packages (
    ID INT,
    Salary FLOAT
);