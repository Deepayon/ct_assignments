CREATE TABLE contests (
    contest_id INT,
    hacker_id INT,
    name VARCHAR(255),
);