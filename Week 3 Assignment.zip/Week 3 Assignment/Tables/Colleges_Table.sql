CREATE TABLE Colleges (
    college_id INT,
    contest_id INT
);