CREATE TABLE BST (
    N INT,
    P INT
);