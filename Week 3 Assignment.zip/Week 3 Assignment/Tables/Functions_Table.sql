CREATE TABLE Functions (
    X int,
    Y int
);