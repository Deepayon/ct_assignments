CREATE TABLE Challenges (
    challenge_id INT,
    college_id INT
);