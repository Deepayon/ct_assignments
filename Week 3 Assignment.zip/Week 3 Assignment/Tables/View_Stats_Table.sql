CREATE TABLE View_Stats (
    challenge_id INT,
    total_views INT,
    total_unique_views INT
);