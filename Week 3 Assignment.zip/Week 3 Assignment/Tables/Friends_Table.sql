CREATE TABLE Friends (
    ID INT,
    Friend_ID INT
);