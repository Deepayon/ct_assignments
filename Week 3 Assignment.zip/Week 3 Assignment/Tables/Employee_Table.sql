CREATE TABLE Employee (
    employee_code VARCHAR(10),
	manager_code VARCHAR(10),
	senior_manager_code VARCHAR(10),
    lead_manager_code VARCHAR(10),
    company_code VARCHAR(10)
);