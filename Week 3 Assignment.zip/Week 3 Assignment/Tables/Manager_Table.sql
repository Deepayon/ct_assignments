CREATE TABLE Manager (
    manager_code VARCHAR(10),
	senior_manager_code VARCHAR(10),
    lead_manager_code VARCHAR(10),
    company_code VARCHAR(10)
);
