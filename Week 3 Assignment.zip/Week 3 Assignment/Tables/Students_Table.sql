CREATE TABLE Students (
    ID INT,
    Name VARCHAR(255)
);