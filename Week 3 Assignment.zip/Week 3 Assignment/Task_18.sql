WITH MonthlyData AS (
    SELECT 'January' AS MonthName, 50000 AS MonthlySalary, 10 AS Headcount
    UNION ALL
    SELECT 'February' AS MonthName, 55000 AS MonthlySalary, 12 AS Headcount-
)

SELECT 
    MonthName,
    MonthlySalary,
    Headcount,
    MonthlySalary * Headcount AS TotalMonthlyCost,
    MonthlySalary * Headcount / Headcount AS WeightedAverageCost
FROM MonthlyData;