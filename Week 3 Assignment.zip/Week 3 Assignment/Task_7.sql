DECLARE @max_num INT = 1000;
DECLARE @num INT = 2;
DECLARE @primes VARCHAR(MAX) = '';

WHILE @num <= @max_num
BEGIN
    DECLARE @is_prime BIT = 1;
    DECLARE @divisor INT = 2;

    WHILE @divisor <= SQRT(@num)
    BEGIN
        IF @num % @divisor = 0
        BEGIN
            SET @is_prime = 0;
            BREAK;
        END
        SET @divisor = @divisor + 1;
    END

    IF @is_prime = 1
    BEGIN
        SET @primes = CONCAT(@primes, '&', CAST(@num AS VARCHAR));
    END

    SET @num = @num + 1;
END

SET @primes = SUBSTRING(@primes, 2, LEN(@primes) - 1);

SELECT @primes AS Primes;