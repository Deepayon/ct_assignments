WITH Employees AS (
    SELECT 'John' AS EmployeeName, 3000 AS Salary
    UNION ALL
    SELECT 'Jane', 4000
    UNION ALL
    SELECT 'Alice', 3500
    UNION ALL
    SELECT 'Bob', 3200
    UNION ALL
    SELECT 'Eve', 5000
),
MiscalculatedAverage AS (
    SELECT AVG(CAST(REPLACE(CONVERT(VARCHAR, Salary), '0', '') AS DECIMAL)) AS MiscalculatedAvg
    FROM Employees
),
ActualAverage AS (
    SELECT AVG(Salary) AS ActualAvg
    FROM Employees
)
SELECT CEILING(ActualAvg - MiscalculatedAvg) AS Difference
FROM ActualAverage
CROSS JOIN MiscalculatedAverage;