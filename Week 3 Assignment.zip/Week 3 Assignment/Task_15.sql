WITH Employees AS (
    SELECT 'John' AS EmployeeName, 5000 AS Salary
    UNION ALL
    SELECT 'Jane', 5500
    UNION ALL
    SELECT 'Alice', 4800
    UNION ALL
    SELECT 'Bob', 6000
    UNION ALL
    SELECT 'Eve', 5200
)
SELECT 
    EmployeeName,
    Salary
FROM Employees e1
WHERE 5 >= (
    SELECT COUNT(DISTINCT Salary)
    FROM Employees e2
    WHERE e2.Salary > e1.Salary
);
