INSERT INTO Students (ID, Name)
VALUES
    (1, 'Ashley'),
    (2, 'Samantha'),
    (3, 'Julia'),
    (4, 'Scarlet');