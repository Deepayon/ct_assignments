INSERT INTO Friends (ID, Friend_ID)
VALUES
    (1, 2),
    (2, 3),
    (3, 4),
    (4, 1);