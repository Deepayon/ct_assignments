INSERT INTO Submission_Stats (challenge_id, total_submissions, total_accepted_submissions)
VALUES
    (75516, 34, 12),
    (47127, 56, 18),
    (47127, 28, 10),
    (75516, 74, 12),
    (75516, 83, 8),
    (72974, 68, 24),
    (72974, 82, 14),
	(47127, 28, 11);