INSERT INTO Senior_Manager (senior_manager_code, lead_manager_code, company_code)
VALUES
    ('SM1', 'LM1', 'C1'),
    ('SM2', 'LM1', 'C1'),
    ('SM3', 'LM2', 'C2');