INSERT INTO contests (contest_id, hacker_id, name)
VALUES
    (66406, 17973, 'Rose'),
    (66556, 79153, 'Angela'),
    (94828, 80275, 'Frank');