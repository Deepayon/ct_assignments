INSERT INTO Colleges (college_id, contest_id)
VALUES
    (11219, 66406),
    (32473, 66556),
	(56685, 94828
);