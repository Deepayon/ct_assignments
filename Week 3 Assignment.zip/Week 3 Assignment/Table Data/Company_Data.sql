INSERT INTO Company (company_code, founder)
VALUES
    ('C1', 'Monika'),
    ('C2', 'Samantha');