INSERT INTO Lead_Manager (lead_manager_code, company_code)
VALUES
    ('LM1', 'C1'),
    ('LM2', 'C2');