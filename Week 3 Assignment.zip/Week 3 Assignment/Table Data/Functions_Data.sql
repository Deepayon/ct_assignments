INSERT INTO Functions (X, Y)
VALUES
    (20, 20),
	(20, 20),
    (20, 21),
    (23, 22),
	(22, 23),
    (21, 20);
