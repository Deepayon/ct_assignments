INSERT INTO STATION (ID, CITY, STATE, LAT_N, LONG_W)
VALUES
    (1, 'Seattle', 'WA', 47, -122),
    (2, 'New York', 'NY', 40, -74),
    (3, 'Los Angeles', 'CA', 34, -118);