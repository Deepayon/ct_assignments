INSERT INTO Challenges (challenge_id, college_id)
VALUES
    (18765, 11219),
    (47127, 11219),
    (60292, 32473),
    (72974, 56685);