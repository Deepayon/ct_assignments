INSERT INTO Packages (ID, Salary)
VALUES
    (1, 15.20),
    (2, 10.06),
    (3, 11.55),
    (4, 12.12);