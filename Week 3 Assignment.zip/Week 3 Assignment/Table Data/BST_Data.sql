INSERT INTO BST (N, P)
VALUES
    (1, 2),  
    (3, 2),      
    (6, 8),     
    (9, 8),   
    (2, 5),      
    (8, 5),  
    (5, NULL);  