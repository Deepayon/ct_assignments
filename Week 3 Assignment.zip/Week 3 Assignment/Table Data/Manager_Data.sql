INSERT INTO Manager (manager_code,senior_manager_code, lead_manager_code, company_code)
VALUES
    ('M1', 'SM1', 'LM1', 'C1'),
    ('M2','SM3', 'LM2', 'C2'),
    ('M3','SM3', 'LM2', 'C2');