WITH MonthlyData AS (
    SELECT '2023-01' AS Month, 5000 AS Cost, 10000 AS Revenue UNION ALL
    SELECT '2023-02' AS Month, 5500 AS Cost, 11000 AS Revenue UNION ALL
    SELECT '2023-03' AS Month, 6000 AS Cost, 12000 AS Revenue
    -- Add more data for other months if needed
)
SELECT
    Month,
    Cost,
    Revenue,
    ROUND(Cost * 100.0 / NULLIF(Revenue, 0), 2) AS CostToRevenueRatio
FROM MonthlyData;