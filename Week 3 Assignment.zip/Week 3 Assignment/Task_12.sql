WITH JobFamily AS (
    SELECT 'Engineering' AS JobFamilyName, 5000 AS Cost, 'India' AS Region
    UNION ALL
    SELECT 'Engineering' AS JobFamilyName, 8000 AS Cost, 'International' AS Region
    UNION ALL
    SELECT 'Marketing' AS JobFamilyName, 3000 AS Cost, 'India' AS Region
    UNION ALL
    SELECT 'Marketing' AS JobFamilyName, 6000 AS Cost, 'International' AS Region
    UNION ALL
    SELECT 'Sales' AS JobFamilyName, 4000 AS Cost, 'India' AS Region
    UNION ALL
    SELECT 'Sales' AS JobFamilyName, 7000 AS Cost, 'International' AS Region
),
TotalCostByJobFamily AS (
    SELECT
        JobFamilyName,
        SUM(CASE WHEN Region = 'India' THEN Cost ELSE 0 END) AS CostIndia,
        SUM(CASE WHEN Region = 'International' THEN Cost ELSE 0 END) AS CostInternational
    FROM JobFamily
    GROUP BY JobFamilyName
)
SELECT
    JobFamilyName,
    CostIndia,
    CostInternational,
    ROUND((CostInternational - CostIndia) / NULLIF(CostIndia, 0) * 100, 2) AS PercentageInternational,
    ROUND((CostInternational - CostIndia) / NULLIF(CostIndia, 0) * 100, 2) AS PercentageIndia
FROM
    TotalCostByJobFamily
ORDER BY
    JobFamilyName;