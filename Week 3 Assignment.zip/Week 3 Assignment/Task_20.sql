WITH SourceTable AS (
    SELECT 'John' AS Name, 3000 AS Salary, 'New York' AS Location
    UNION ALL
    SELECT 'Alice', 3200, 'Los Angeles'
    UNION ALL
    SELECT 'Bob', 3500, 'Chicago'

),
DestinationTable AS (
    SELECT 'Mary' AS Name, 2800 AS Salary, 'Houston' AS Location
    UNION ALL
    SELECT 'David', 2900, 'Miami'
)

SELECT *
INTO DestinationTable  
FROM SourceTable
WHERE NOT EXISTS (
    SELECT 1
    FROM DestinationTable
    WHERE DestinationTable.Name = SourceTable.Name
      AND DestinationTable.Salary = SourceTable.Salary
      AND DestinationTable.Location = SourceTable.Location
);
