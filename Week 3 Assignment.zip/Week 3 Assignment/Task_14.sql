WITH EmployeeData AS (
    SELECT 'SubBand_A' AS SubBand, 'Employee_1' AS EmployeeID UNION ALL
    SELECT 'SubBand_A' AS SubBand, 'Employee_2' AS EmployeeID UNION ALL
    SELECT 'SubBand_B' AS SubBand, 'Employee_3' AS EmployeeID UNION ALL
    SELECT 'SubBand_B' AS SubBand, 'Employee_4' AS EmployeeID UNION ALL
    SELECT 'SubBand_B' AS SubBand, 'Employee_5' AS EmployeeID UNION ALL
    SELECT 'SubBand_C' AS SubBand, 'Employee_6' AS EmployeeID UNION ALL
    SELECT 'SubBand_C' AS SubBand, 'Employee_7' AS EmployeeID
)

SELECT 
    SubBand,
    COUNT(EmployeeID) AS Headcount,
    ROUND((COUNT(EmployeeID) * 100.0) / (SELECT COUNT(*) FROM EmployeeData), 2) AS Percentage
FROM EmployeeData
GROUP BY SubBand
ORDER BY SubBand;