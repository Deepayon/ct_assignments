CREATE PROCEDURE AllocateSubjects
AS
BEGIN
    DECLARE @student_id INT;
    DECLARE @subject_id VARCHAR(10);
    DECLARE @pref INT;

    DECLARE cur CURSOR LOCAL FOR 
        SELECT sp.StudentId, sp.SubjectId, sp.Preference
        FROM StudentPreference sp
        ORDER BY sp.StudentId, sp.Preference;

    CREATE TABLE #TempAllocation (
        StudentId INT,
        SubjectId VARCHAR(10),
        Allocated BIT DEFAULT 0
    );

    OPEN cur;

    FETCH NEXT FROM cur INTO @student_id, @subject_id, @pref;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        DECLARE @remaining_seats INT;
        SELECT @remaining_seats = RemainingSeats
        FROM SubjectDetails
        WHERE SubjectId = @subject_id;

        IF @remaining_seats > 0
        BEGIN
           INSERT INTO #TempAllocation (StudentId, SubjectId, Allocated)
            VALUES (@student_id, @subject_id, 1);

           UPDATE SubjectDetails
            SET RemainingSeats = RemainingSeats - 1
            WHERE SubjectId = @subject_id;
        END;

        FETCH NEXT FROM cur INTO @student_id, @subject_id, @pref;
    END; 

    CLOSE cur;
    DEALLOCATE cur;

    INSERT INTO Allotments (StudentId, SubjectId)
    SELECT StudentId, SubjectId
    FROM #TempAllocation
    WHERE Allocated = 1;

    INSERT INTO UnallotedStudents (StudentId)
    SELECT sp.StudentId
    FROM StudentPreference sp
    LEFT JOIN #TempAllocation ta ON sp.StudentId = ta.StudentId
    WHERE ta.StudentId IS NULL;

    DROP TABLE #TempAllocation;
    
END;