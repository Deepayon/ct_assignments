SELECT soh.OrderDate
FROM Sales.SalesOrderHeader soh
WHERE soh.SalesOrderID = (
    SELECT TOP 1 sod.SalesOrderID
    FROM Sales.SalesOrderDetail sod
    GROUP BY sod.SalesOrderID
    ORDER BY SUM(sod.LineTotal) DESC
);
