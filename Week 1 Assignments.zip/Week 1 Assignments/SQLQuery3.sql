SELECT CONCAT(p.FirstName, ' ', p.MiddleName, ' ', p.LastName) AS FullName, a.City
FROM Person.Person AS p
INNER JOIN Person.Address AS a ON p.BusinessEntityID = a.AddressID  
WHERE a.City IN ('Berlin', 'London');
