SELECT 
  SalesOrderDetail.SalesOrderID,
  MIN(SalesOrderDetail.OrderQty) AS MinimumQuantity,
  MAX(SalesOrderDetail.OrderQty) AS MaximumQuantity
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderDetail.SalesOrderID;