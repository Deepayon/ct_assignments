SELECT DISTINCT p.Name
FROM Sales.SalesOrderDetail sod
JOIN Sales.SalesOrderHeader soh ON sod.SalesOrderID = soh.SalesOrderID
JOIN Person.Address a ON soh.ShipToAddressID = a.AddressID
JOIN Sales.SalesTerritory st ON a.StateProvinceID = st.TerritoryID
JOIN Production.Product p ON sod.ProductID = p.ProductID
WHERE st.CountryRegionCode = 'FR';