SELECT DISTINCT p.FirstName,p.MiddleName, p.LastName
FROM Sales.Customer c
JOIN Sales.SalesOrderHeader soh ON c.CustomerID = soh.CustomerID
JOIN Sales.SalesOrderDetail sod ON soh.SalesOrderID = sod.SalesOrderID
JOIN Production.Product pr ON sod.ProductID = pr.ProductID
JOIN Person.Person p ON c.PersonID = p.BusinessEntityID
JOIN Person.BusinessEntityAddress ba ON p.BusinessEntityID = ba.BusinessEntityID
JOIN Person.Address a ON ba.AddressID = a.AddressID
WHERE a.City = 'London' AND pr.Name = 'Chai';