SELECT TOP 1 SalesOrderID, OrderDate, TotalDue, CustomerID, ShipToAddressID, BillToAddressID
FROM Sales.SalesOrderHeader
ORDER BY TotalDue DESC;