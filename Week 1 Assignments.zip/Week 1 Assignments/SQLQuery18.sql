SELECT soh.SalesOrderID, soh.OrderDate, soh.TotalDue, a.AddressLine1, a.AddressLine2, a.City, sp.Name AS StateProvince, cr.Name AS Country
FROM Sales.SalesOrderHeader soh
JOIN Person.Address a ON soh.ShipToAddressID = a.AddressID
JOIN Person.StateProvince sp ON a.StateProvinceID = sp.StateProvinceID
JOIN Person.CountryRegion cr ON sp.CountryRegionCode = cr.CountryRegionCode
WHERE cr.Name = 'Canada';