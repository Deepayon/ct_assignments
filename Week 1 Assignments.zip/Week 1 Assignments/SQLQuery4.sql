SELECT CONCAT(p.FirstName, ' ', p.MiddleName, ' ', p.LastName) AS FullName, st.CountryRegionCode
FROM Person.Person AS p
INNER JOIN Sales.Customer AS c ON p.BusinessEntityID = c.CustomerID
INNER JOIN Sales.SalesTerritory AS st ON c.TerritoryID = st.TerritoryID
WHERE st.CountryRegionCode IN ('GB', 'US');
