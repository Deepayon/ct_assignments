SELECT p.FirstName, p.LastName, COUNT(e.BusinessEntityID) AS ReportCount
FROM HumanResources.Employee e
JOIN HumanResources.Employee m ON e.OrganizationNode.GetAncestor(1) = m.OrganizationNode
JOIN Person.Person p ON m.BusinessEntityID = p.BusinessEntityID
GROUP BY p.FirstName, p.LastName
HAVING COUNT(e.BusinessEntityID) > 4;