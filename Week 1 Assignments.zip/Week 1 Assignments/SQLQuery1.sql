SELECT CONCAT(FirstName, ' ', MiddleName, ' ', LastName) AS FullName
FROM AdventureWorks2022.Person.Person