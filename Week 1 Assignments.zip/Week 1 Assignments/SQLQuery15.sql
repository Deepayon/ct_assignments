SELECT
    Manager.FirstName + ' ' + Manager.LastName AS ManagerName,
    COUNT(Employee.BusinessEntityID) AS TotalEmployees
FROM
    EmployeeHierarchy AS Employee
JOIN
    EmployeeHierarchy AS Manager ON Manager.OrganizationNode.GetAncestor(1) = Employee.OrganizationNode
GROUP BY
    Manager.FirstName, Manager.LastName
ORDER BY
    ManagerName;