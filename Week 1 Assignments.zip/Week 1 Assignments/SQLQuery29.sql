SELECT soh.SalesOrderID, soh.OrderDate, soh.TotalDue
FROM Sales.SalesOrderHeader soh
WHERE soh.CustomerID = (
    SELECT TOP 1 soh.CustomerID
    FROM Sales.SalesOrderHeader soh
    GROUP BY soh.CustomerID
    ORDER BY SUM(soh.TotalDue) DESC
);