SELECT 
    sp.BusinessEntityID AS EmployeeID,
    CONCAT(p.FirstName, ' ', p.LastName) AS EmployeeName,
    COUNT(soh.SalesOrderID) AS NumberOfOrders
FROM 
    Sales.SalesOrderHeader soh
JOIN 
    Sales.SalesPerson sp ON soh.SalesPersonID = sp.BusinessEntityID
JOIN 
    Person.Person p ON sp.BusinessEntityID = p.BusinessEntityID
JOIN 
    Sales.Customer c ON soh.CustomerID = c.CustomerID
WHERE 
    LEFT(c.CustomerID, 1) BETWEEN 'A' AND 'AO'
GROUP BY 
    sp.BusinessEntityID, p.FirstName, p.LastName
ORDER BY 
    NumberOfOrders DESC;