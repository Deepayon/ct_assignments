SELECT 
  SalesOrderDetail.SalesOrderID,
  AVG(SalesOrderDetail.OrderQty) AS AverageQuantity
FROM Sales.SalesOrderDetail
GROUP BY SalesOrderDetail.SalesOrderID;
