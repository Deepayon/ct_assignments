SELECT 
    pv.BusinessEntityID AS SupplierID,
    COUNT(*) AS NumberOfProductsOffered
FROM 
    Purchasing.ProductVendor pv
GROUP BY 
    pv.BusinessEntityID;