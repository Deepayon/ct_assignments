SELECT Name
FROM Production.Product
WHERE Name LIKE 'A%';
