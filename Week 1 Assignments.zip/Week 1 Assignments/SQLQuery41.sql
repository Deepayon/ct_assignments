SELECT TOP 10
    ISNULL(p.FirstName, '') + ' ' + ISNULL(p.LastName, '') AS CustomerName
FROM 
    Sales.Customer c
JOIN 
    Sales.SalesOrderHeader soh ON c.CustomerID = soh.CustomerID
LEFT JOIN 
    Person.Person p ON c.PersonID = p.BusinessEntityID
GROUP BY 
    c.CustomerID, c.PersonID, p.FirstName, p.LastName
ORDER BY 
    SUM(soh.TotalDue) DESC;
