SELECT SalesOrderID, OrderDate, TotalDue, CustomerID, ShipToAddressID, BillToAddressID
FROM Sales.SalesOrderHeader
WHERE TotalDue > 200;