SELECT Name
FROM Sales.Store
WHERE Name LIKE '%N';