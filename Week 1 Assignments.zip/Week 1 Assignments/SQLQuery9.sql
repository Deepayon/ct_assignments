
SELECT p.FirstName, p.MiddleName, p.LastName
FROM Sales.Customer c
LEFT JOIN Sales.SalesOrderHeader soh ON c.CustomerID = soh.CustomerID
JOIN Person.Person p ON c.PersonID = p.BusinessEntityID
WHERE soh.CustomerID IS NULL;
