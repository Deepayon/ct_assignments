USE AdventureWorks2022;
GO

IF OBJECT_ID('dbo.DeleteSalesOrder', 'TR') IS NOT NULL
    DROP TRIGGER dbo.DeleteSalesOrder;
GO

CREATE TRIGGER DeleteSalesOrder
ON Sales.SalesOrderHeader
AFTER DELETE
AS
BEGIN
    DELETE FROM Sales.SalesOrderDetail
    WHERE SalesOrderID IN (SELECT SalesOrderID FROM deleted);

END;
GO