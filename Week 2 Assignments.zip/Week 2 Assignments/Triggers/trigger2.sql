IF OBJECT_ID('dbo.trigOrderDetailsInsert', 'TR') IS NOT NULL
    DROP TRIGGER dbo.trigOrderDetailsInsert;
GO

CREATE TRIGGER trigOrderDetailsInsert
ON Sales.SalesOrderDetail
INSTEAD OF INSERT
AS
BEGIN

    IF EXISTS (
        SELECT od.ProductID, od.OrderQty, p.SafetyStockLevel
        FROM inserted od
        JOIN Production.Product p ON od.ProductID = p.ProductID
        WHERE od.OrderQty > p.SafetyStockLevel
    )
    BEGIN

        RAISERROR('Order could not be filled due to insufficient stock.', 16, 1);
    END
    ELSE
    BEGIN
 
        INSERT INTO Sales.SalesOrderDetail (SalesOrderID, ProductID, OrderQty, UnitPrice, UnitPriceDiscount)
        SELECT SalesOrderID, ProductID, OrderQty, UnitPrice, UnitPriceDiscount
        FROM inserted;

        UPDATE p
        SET p.SafetyStockLevel = p.SafetyStockLevel - od.OrderQty
        FROM Production.Product p
        JOIN inserted od ON p.ProductID = od.ProductID;
    END
END;
GO