CREATE PROCEDURE GetOrderDetails1 
    @OrderID INT
AS
BEGIN
    DECLARE @OrderExists INT

    SELECT @OrderExists = COUNT(*)
    FROM Sales.SalesOrderDetail
    WHERE SalesOrderID = @OrderID

    IF @OrderExists > 0
    BEGIN
        SELECT *
        FROM Sales.SalesOrderDetail
        WHERE SalesOrderID = @OrderID
    END
    ELSE
    BEGIN
        PRINT 'The OrderID ' + CAST(@OrderID AS VARCHAR(10)) + ' does not exist'
        RETURN 1
    END
END