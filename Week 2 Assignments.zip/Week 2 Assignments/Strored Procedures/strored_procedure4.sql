CREATE PROCEDURE DeleteOrderDetails 
    @OrderID INT,
    @ProductID INT
AS
BEGIN
    DECLARE @OrderProductExists INT

    SELECT @OrderProductExists = COUNT(*)
    FROM Sales.SalesOrderDetail
    WHERE SalesOrderID = @OrderID AND ProductID = @ProductID

    IF @OrderProductExists > 0
    BEGIN
        DELETE FROM Sales.SalesOrderDetail
        WHERE SalesOrderID = @OrderID AND ProductID = @ProductID
    END
    ELSE
    BEGIN
        PRINT 'The OrderID ' + CAST(@OrderID AS VARCHAR(10)) + ' or the ProductID ' + CAST(@ProductID AS VARCHAR(10)) + ' does not exist'
        RETURN -1
    END
END