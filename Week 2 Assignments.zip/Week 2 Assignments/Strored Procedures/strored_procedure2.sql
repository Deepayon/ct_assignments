CREATE OR ALTER PROCEDURE UpdateOrderDetails
    @OrderID int,
    @ProductID int,
    @UnitPrice money = NULL,
    @Quantity int = NULL,
    @Discount float = NULL
AS
BEGIN
    DECLARE @UnitsInStock int, @ReorderLevel int, @ActualUnitPrice money, @ActualQuantity int;

    SELECT @UnitsInStock = UnitsInStock, @ReorderLevel = ReorderLevel, @ActualUnitPrice = UnitPrice, @ActualQuantity = OrderQty
    FROM Production.Product
    INNER JOIN Sales.SalesOrderDetail ON Sales.SalesOrderDetail.ProductID = Production.Product.ProductID
    WHERE Sales.SalesOrderDetail.SalesOrderID = @OrderID AND Sales.SalesOrderDetail.ProductID = @ProductID;

    SET @UnitPrice = ISNULL(@UnitPrice, @ActualUnitPrice);
    SET @Quantity = ISNULL(@Quantity, @ActualQuantity);
    SET @Discount = ISNULL(@Discount, 0);

    UPDATE Sales.SalesOrderDetail
    SET UnitPrice = @UnitPrice, OrderQty = @Quantity, UnitPriceDiscount = @Discount
    WHERE SalesOrderID = @OrderID AND ProductID = @ProductID;

    UPDATE Production.Product
    SET UnitsInStock = UnitsInStock - (@Quantity - @ActualQuantity)
    WHERE ProductID = @ProductID;
END