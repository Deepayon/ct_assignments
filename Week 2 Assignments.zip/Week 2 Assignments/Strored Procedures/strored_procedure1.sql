CREATE OR ALTER InsertOrderDetails
    @OrderID int,
    @ProductID int,
    @UnitPrice money = NULL,
    @Quantity int,
    @Discount float = 0
AS
BEGIN
    DECLARE @UnitsInStock int, @ReorderLevel int, @ActualUnitPrice money;

    SELECT @UnitsInStock = UnitsInStock, @ReorderLevel = ReorderLevel, @ActualUnitPrice = UnitPrice
    FROM Production.Product
    WHERE ProductID = @ProductID;

    IF @UnitsInStock < @Quantity
    BEGIN
        PRINT 'There is not enough of a product in stock. The stored procedure was aborted without making any changes to the database.';
        RETURN;
    END

    IF @UnitPrice IS NULL
    BEGIN
        SET @UnitPrice = @ActualUnitPrice;
    END

    INSERT INTO Sales.SalesOrderDetail (SalesOrderID, ProductID, UnitPrice, OrderQty, UnitPriceDiscount)
    VALUES (@OrderID, @ProductID, @UnitPrice, @Quantity, @Discount);

    IF @@ROWCOUNT = 0
    BEGIN
        PRINT 'Failed to place the order. Please try again.';
        RETURN;
    END

    UPDATE Production.Product
    SET UnitsInStock = UnitsInStock - @Quantity
    WHERE ProductID = @ProductID;

    IF @UnitsInStock - @Quantity < @ReorderLevel
    BEGIN
        PRINT 'The quantity in stock of the product has dropped below its Reorder Level as a result of the update.';
    END
END