USE AdventureWorks2022;

GO

CREATE VIEW vwCustomerOrders AS
SELECT 
    COALESCE(st.Name, CONCAT(pp.FirstName, ' ', pp.LastName)) AS CompanyName,
    soh.SalesOrderID AS OrderID,
    soh.OrderDate,
    sod.ProductID,
    p.Name AS ProductName,
    sod.OrderQty AS Quantity,
    sod.UnitPrice,
    (sod.OrderQty * sod.UnitPrice) AS TotalPrice
FROM 
    Sales.SalesOrderDetail sod
JOIN 
    Sales.SalesOrderHeader soh ON sod.SalesOrderID = soh.SalesOrderID
JOIN 
    Production.Product p ON sod.ProductID = p.ProductID
LEFT JOIN 
    Sales.Customer c ON soh.CustomerID = c.CustomerID
LEFT JOIN 
    Person.Person pp ON c.PersonID = pp.BusinessEntityID 
LEFT JOIN 
    Sales.Store st ON c.StoreID = st.BusinessEntityID;
