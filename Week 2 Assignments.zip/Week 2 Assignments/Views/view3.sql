USE AdventureWorks2022;
GO

IF OBJECT_ID('dbo.MyProducts', 'V') IS NOT NULL
    DROP VIEW dbo.MyProducts;
GO

CREATE VIEW dbo.MyProducts AS
SELECT 
    p.ProductID,
    p.Name AS ProductName,
    p.SafetyStockLevel AS QuantityPerUnit,
    p.ListPrice AS UnitPrice,
    v.Name AS CompanyName,
    c.Name AS CategoryName
FROM 
    Production.Product p
JOIN 
    Production.ProductSubcategory ps ON p.ProductSubcategoryID = ps.ProductSubcategoryID
JOIN 
    Production.ProductCategory c ON ps.ProductCategoryID = c.ProductCategoryID
JOIN 
    Purchasing.ProductVendor pv ON p.ProductID = pv.ProductID
JOIN 
    Purchasing.Vendor v ON pv.BusinessEntityID = v.BusinessEntityID
WHERE 
    p.DiscontinuedDate IS NULL;

GO