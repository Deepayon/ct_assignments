USE AdventureWorks2022;

GO

IF OBJECT_ID('dbo.vwCustomerOrdersYesterday', 'V') IS NOT NULL
    DROP VIEW dbo.vwCustomerOrdersYesterday;
GO

CREATE VIEW vwCustomerOrdersYesterday AS
SELECT 
    CompanyName,
    OrderID,
    OrderDate,
    ProductID,
    ProductName,
    Quantity,
    UnitPrice,
    TotalPrice
FROM 
    dbo.vwCustomerOrders
WHERE 
    OrderDate = DATEADD(DAY, DATEDIFF(DAY, 0, GETDATE()) - 1, 0);  

GO